package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "customer_proj1")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {
	@Id
	@Column(name = "customer_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	@Column(name = "phone_number",unique = true)
	private String number;
	private String role;
	@OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
	private List<Order> order=new ArrayList<>();
	@OneToOne(mappedBy = "customer")
    private Cart cart;
	@Column(name="address")
	private String address;
	@Column(name="city")
	private String city;
	@Column(name = "state")
	private String state;
	@Column(name = "pinCode")
	private String pin;
	public Customer(String firstName, String lastName, String email, String password, String number, String role,
			String address, String city, String state, String pin) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.number = number;
		this.role = role;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pin = pin;
	}
	
	
	
}