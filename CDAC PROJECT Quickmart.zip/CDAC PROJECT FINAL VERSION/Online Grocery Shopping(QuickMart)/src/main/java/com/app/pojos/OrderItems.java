package com.app.pojos;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItems {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private long quantity;
	private double discount;
	private double price;
	@ManyToOne
	@JoinColumn(name = "order_id", nullable = false) 
	private Order order;
	@ManyToOne
	@JoinColumn(name = "product_id", nullable = false) 
	private Product product;
	public OrderItems(long quantity, double discount, double price, Order order, Product product) {
		super();
		this.quantity = quantity;
		this.discount = discount;
		this.price = price;
		this.order = order;
		this.product = product;
	}
	
	
}
