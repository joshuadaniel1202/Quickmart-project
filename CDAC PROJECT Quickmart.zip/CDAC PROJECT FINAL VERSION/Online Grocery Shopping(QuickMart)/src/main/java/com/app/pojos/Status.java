package com.app.pojos;

public enum Status {
	PLACED,DELIVERED,OUT_FOR_DELIVERY,PROCESSING,FAILED
}
