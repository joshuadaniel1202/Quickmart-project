package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CdacProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(CdacProject1Application.class, args);
	}

}
